import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lezione7/question_layout/question_index_layout.dart';

class SummaryItem extends StatelessWidget {
  const SummaryItem(this.summaryItem, {super.key});
  final Map<String, Object> summaryItem;
  @override
  Widget build(BuildContext context) {
    final isCorrect = summaryItem['risposta corretta'] ==
        summaryItem['risposta dell\'utente'];
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          QuestionIndexLayout(
              isCorrect: isCorrect,
              questionIndex: summaryItem['indice_domanda'] as int),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  summaryItem['domanda'] as String,
                  style: GoogleFonts.roboto(
                    textStyle: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  summaryItem['risposta dell\'utente'] as String,
                  style: GoogleFonts.roboto(
                    textStyle: const TextStyle(
                        fontSize: 12, fontStyle: FontStyle.italic),
                  ),
                ),
                Container(
                  color: Colors.green,
                  child: Text(
                    summaryItem['risposta corretta'] as String,
                    style: GoogleFonts.roboto(
                      textStyle:
                          const TextStyle(fontSize: 12, color: Colors.white),
                    ),
                  ),
                ),
                const Divider(color: Colors.white),
              ],
            ),
          )
        ],
      ),
    );
  }
}
