import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:lezione7/question_layout/summary_item.dart';

class QuestionSummary2 extends StatelessWidget {
  const QuestionSummary2(this.summaryData, {super.key});
  final List<Map<String, Object>> summaryData;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 400,
      child: SingleChildScrollView(
        child: Column(
          children: summaryData.map(
            // crea dei widget popolandoli con i dostri dati
            (data) {
              return SummaryItem(data);
            },
          ).toList(),
        ),
      ),
    );
  }
}
