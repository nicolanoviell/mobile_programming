import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:lezione7/data/questions.dart';
import 'package:lezione7/question_layout/question_summary_new.dart';
import 'package:google_fonts/google_fonts.dart';

class ResultWidget extends StatelessWidget {
  const ResultWidget({
    super.key,
    required this.chosenAnswers,
    required this.onRestart,
  });
  final List<String> chosenAnswers;
  final void Function() onRestart;

  List<Map<String, Object>> getSummaryData() {
    final List<Map<String, Object>> summary = [];
    for (var i = 0; i < chosenAnswers.length; i++) {
      summary.add(
        {
          'indice_domanda': i,
          'domanda': questions[i].question,
          'risposta corretta': questions[i].answers[0],
          'risposta dell\'utente': chosenAnswers[i],
        },
      );
    }
    return summary;
  }

  @override
  Widget build(BuildContext context) {
    final summaryData = getSummaryData();
    final nunTotalDomande = questions.length;
    final numRisposteCorrette = summaryData
        .where((element) =>
            element['risposta corretta'] == element['risposta dell\'utente'])
        .length;
    return SizedBox(
      width: double.infinity, // allargamento massimo
      child: Container(
        margin: const EdgeInsets.all(40.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Hai risposto correttamente a $numRisposteCorrette domande su $nunTotalDomande',
              style: GoogleFonts.lobster(
                textStyle:
                    const TextStyle(fontSize: 16, fontStyle: FontStyle.italic),
                color: Colors.white,
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            QuestionSummary2(summaryData),
            const SizedBox(
              height: 30,
            ),
            TextButton.icon(
              onPressed: onRestart,
              style: TextButton.styleFrom(
                foregroundColor: Colors.white,
              ),
              icon: const Icon(Icons.refresh),
              label: const Text('Ricomincia'),
            ),
          ],
        ),
      ),
    );
  }
}
