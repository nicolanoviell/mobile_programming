import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:lezione9/services/location.dart';
import 'package:lezione9/services/networking.dart';

class LoadingScreen extends StatefulWidget {
  const LoadingScreen({super.key});

  @override
  State<LoadingScreen> createState() => _LoadingScreenState();
}

class _LoadingScreenState extends State<LoadingScreen> {
  double? latitude;
  double? longitude;
  @override
  void initState() {
    super.initState();
    getLocationData();
  }

  void getLocationData() async {
    Location location = Location();
    await location.getCurrentLocation();
    latitude = location.latitude;
    longitude = location.longitude;
    NetworkHelper networkHelper = NetworkHelper(
      Uri.parse(
          'https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude&hourly=temperature_2m'),
    );
    var meteodata = await networkHelper.getData();
    var time = meteodata['hourly']['time'][0];
    double temperature = meteodata['hourly']['temperature_2m'][0];
    print(time);
    print(temperature);
    print(location);
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold();
  }
}
