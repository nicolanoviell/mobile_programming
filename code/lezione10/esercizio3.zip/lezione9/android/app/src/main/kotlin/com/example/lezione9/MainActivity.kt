package com.example.lezione9

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
