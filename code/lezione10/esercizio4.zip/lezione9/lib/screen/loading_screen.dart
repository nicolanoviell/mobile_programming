import 'package:flutter/material.dart';
import 'package:lezione9/services/location.dart';
import 'package:lezione9/services/networking.dart';
import 'package:lezione9/screen/location_screen.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

class LoadingScreen extends StatefulWidget {
  const LoadingScreen({super.key});

  @override
  State<LoadingScreen> createState() => _LoadingScreenState();
}

class _LoadingScreenState extends State<LoadingScreen> {
  double? latitude;
  double? longitude;
  @override
  void initState() {
    super.initState();
    getLocationData();
  }

  void getLocationData() async {
    Location location = Location();
    await location.getCurrentLocation();
    latitude = location.latitude;
    longitude = location.longitude;
    NetworkHelper networkHelper = NetworkHelper(
      Uri.parse(
          'https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude&hourly=temperature_2m'),
    );
    var meteodata = await networkHelper.getData();
    // var time = meteodata['hourly']['time'][0];
    // double temperature = meteodata['hourly']['temperature_2m'][0];
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) {
        return LocationScreen(
          meteosimulatore: meteodata,
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.white,
        child: const Center(
          child: SpinKitDoubleBounce(
            color: Colors.black,
            size: 100.0,
          ),
        ),
      ),
    );
  }
}
