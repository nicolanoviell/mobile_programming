import 'package:flutter/material.dart';

class LocationScreen extends StatefulWidget {
  const LocationScreen({super.key, this.meteosimulatore});
  final dynamic meteosimulatore;

  @override
  State<LocationScreen> createState() => _LocationScreenState();
}

class _LocationScreenState extends State<LocationScreen> {
  late double temperature;
  late String time;
  String? icona;
  @override
  void initState() {
    super.initState();
    //print(widget.meteosimulatore);
    updateUI(widget.meteosimulatore);
  }

  void updateUI(dynamic meteoData) {
    time = meteoData['hourly']['time'][0];
    temperature = meteoData['hourly']['temperature_2m'][0];
    icona = getIcon(temperature);
  }

  String getIcon(double temperature) {
    if (temperature > 22) {
      return '☀️'; // Sun emoji
    } else if (temperature > 10) {
      return '☁️'; // Cloud emoji
    } else {
      return '❄️'; // Snowflake emoji
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset('assets/comevestirmi.jpeg'),
            Center(
              child: Text(
                'Il giorno $time ci saranno $temperature gradi $icona',
                style: const TextStyle(
                  fontSize: 24,
                  color: Colors.black,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
