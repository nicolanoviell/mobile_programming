import 'package:flutter/material.dart';
import 'package:lezione6/voto.dart';

const startAlign = Alignment.topLeft;
const endAlign = Alignment.bottomRight;

class MyWidget extends StatelessWidget {
  const MyWidget({super.key, required this.color1, required this.color2});
  const MyWidget.appdefault({super.key})
      : color1 = const Color.fromARGB(255, 58, 40, 89),
        color2 = const Color.fromARGB(255, 220, 20, 17);
  final Color color1;
  final Color color2;

  @override
  Widget build(BuildContext context) {
    return Container(
      // definiamo lo stile con Container
      decoration: BoxDecoration(
        // definiamo il gradiente
        gradient: LinearGradient(
          // specifica il gradiente
          begin: startAlign,
          end: endAlign,
          colors: [color1, color2],
        ),
      ),
      child: const Center(
        child: Voto(),
      ),
    );
  }
}
