import 'package:flutter/material.dart';
import 'package:lezione6/my_widget.dart';
import 'package:lezione6/my_text.dart';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const MyText('Programmazione Mobile'),
          backgroundColor: const Color.fromARGB(255, 36, 52, 73),
        ), // titolo dell'app
        // body: const MyWidget(
        //   color1: Color.fromARGB(255, 58, 40, 89),
        //   color2: Color.fromARGB(255, 220, 20, 17),
        // ),
        body: const MyWidget.appdefault(),
      ),
    ),
  );
}
