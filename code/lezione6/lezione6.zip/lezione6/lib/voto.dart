import 'package:flutter/material.dart';
import 'package:lezione6/my_text.dart';
import 'dart:math';

final randomizer = Random();

// se vuoi scrivere decentemente il codice, crea una classe Range
// e usa la funzione generaVoto() commentata
// class Range {
//   final int start;
//   final int end;

//   Range(this.start, this.end);

//   bool includes(int value) => start <= value && value <= end;
// }

class Voto extends StatefulWidget {
  const Voto({super.key});

  @override
  State<Voto> createState() => _VotoState();
}

class _VotoState extends State<Voto> {
  var immagineVoto = 'images/registro.jpeg';
  var currentGrade = 0;
  void generaVoto() {
    setState(() {
      currentGrade =
          randomizer.nextInt(21) + 11; // genera un numero tra 11 e 31
      if (currentGrade >= 11 && currentGrade <= 14) {
        immagineVoto = 'images/bocciato.jpeg';
      } else if (currentGrade >= 15 && currentGrade <= 17) {
        immagineVoto = 'images/perpoco.jpeg';
      } else if (currentGrade >= 18 && currentGrade <= 26) {
        immagineVoto = 'images/medio.jpeg';
      } else if (currentGrade >= 27 && currentGrade <= 31) {
        immagineVoto = 'images/alto.jpeg';
      }
    });
  }
  // void generaVoto() {
  //   setState(() {
  //     currentGrade =
  //         randomizer.nextInt(21) + 11; // generates a number between 11 and 31
  //     print(currentGrade);

  //     Map<Range, String> gradeImages = {
  //       Range(11, 14): 'images/bocciato.jpeg',
  //       Range(15, 17): 'images/perpoco.jpeg',
  //       Range(18, 26): 'images/medio.jpeg',
  //       Range(27, 31): 'images/alto.jpeg',
  //     };

  //     for (var entry in gradeImages.entries) {
  //       if (entry.key.includes(currentGrade)) {
  //         immagineVoto = entry.value;
  //         break;
  //       }
  //     }
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Image(
          image: AssetImage(immagineVoto),
          width: 400,
        ),
        const SizedBox(height: 20),
        const MyText('Come andrà l\'esame?'),
        const SizedBox(height: 50),
        // ElevatedButton(onPressed: onPressed, child: child) // questo pulsante ha background e ombra
        TextButton(
            onPressed: generaVoto,
            child: const MyText(
                'Scoprilo toccando qui')) // questo pulsante ha solo un testo "pressable"
        // OutlinedButton(onPressed: onPressed, child: child) // questo pulsante ha solo il contorno
      ],
    );
  }
}
