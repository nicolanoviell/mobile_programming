import 'dart:async';

import 'package:flutter/widgets.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

void main() async {
  // Necessario ad evitare errori causati da flutter upgrade.
  // 'package:flutter/widgets.dart' è richiesto.
  WidgetsFlutterBinding.ensureInitialized();
  // Apri il database e memorizza il riferimento.
  final database = openDatabase(
    // Imposta il percorso del database. Nota: Utilizzare la funzione `join` del
    // pacchetto `path` è una pratica consigliata per assicurarsi che il percorso
    // sia correttamente costruito per ogni piattaforma.
    join(await getDatabasesPath(), 'doggie_database.db'),
    // Quando il database viene creato per la prima volta, crea una tabella per memorizzare i cani.
    onCreate: (db, version) {
      // Esegui l'istruzione CREATE TABLE sul database.
      return db.execute(
        'CREATE TABLE dogs(id INTEGER PRIMARY KEY, name TEXT, age INTEGER)',
      );
    },
    // Imposta la versione. Questo esegue la funzione onCreate e fornisce un
    // percorso per eseguire aggiornamenti e downgrade del database.
    version: 1,
  );

  // Definisci una funzione che inserisce i cani nel database
  Future<void> insertDog(Dog dog) async {
    // Ottieni un riferimento al database.
    final db = await database;

    // Inserisci il cane nella tabella corretta. Puoi anche specificare
    // conflictAlgorithm: ConflictAlgorithm.replace, da utilizzare nel caso in cui lo stesso cane venga inserito due volte.
    //
    // In questo caso, sostituisci eventuali dati precedenti.
    await db.insert(
      'dogs',
      dog.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // Un metodo che recupera tutti i cani dalla tabella dogs.
  Future<List<Dog>> dogs() async {
    // Ottieni un riferimento al database.
    final db = await database;

    // Esegui una query sulla tabella per ottenere tutti i cani.
    final List<Map<String, Object?>> dogMaps = await db.query('dogs');

    // Converti la lista dei campi di ogni cane in una lista di oggetti `Dog`.
    return [
      for (final {
            'id': id as int,
            'name': name as String,
            'age': age as int,
          } in dogMaps)
        Dog(id: id, name: name, age: age),
    ];
  }

  Future<void> updateDog(Dog dog) async {
    // Ottieni un riferimento al database.
    final db = await database;

    // Aggiorna il cane fornito.
    await db.update(
      'dogs',
      dog.toMap(),
      // Assicurati che il cane abbia un id corrispondente.
      where: 'id = ?',
      // Passa l'id del cane come whereArg per prevenire l'SQL injection.
      whereArgs: [dog.id],
    );
  }

  Future<void> deleteDog(int id) async {
    // Ottieni un riferimento al database.
    final db = await database;

    // Rimuovi il cane dal database.
    await db.delete(
      'dogs',
      // Utilizza una clausola `where` per eliminare una entry specifica.
      where: 'id = ?',
      // Passa l'id del cane come whereArg per prevenire l'SQL injection.
      whereArgs: [id],
    );
  }

  // Crea un cane e aggiungilo alla tabella dei cani
  var fido = Dog(
    id: 0,
    name: 'Fido',
    age: 35,
  );

  await insertDog(fido);

  // Ora, utilizza il metodo sopra per recuperare tutti i cani.
  print(await dogs()); // Stampa una lista che include Fido.

  // Aggiorna l'età di Fido e salvalo nel database.
  fido = Dog(
    id: fido.id,
    name: fido.name,
    age: fido.age + 7,
  );
  await updateDog(fido);

  // Stampa i risultati aggiornati.
  print(await dogs()); // Stampa Fido con età 42.

  // Elimina Fido dal database.
  await deleteDog(fido.id);

  // Stampa la lista dei cani (vuota).
  print(await dogs());
}

class Dog {
  final int id;
  final String name;
  final int age;

  Dog({
    required this.id,
    required this.name,
    required this.age,
  });

  // Converte un cane in una mappa. Le chiavi devono corrispondere ai nomi delle
  // colonne nel database.
  Map<String, Object?> toMap() {
    return {
      'id': id,
      'name': name,
      'age': age,
    };
  }

  // Implementa toString per facilitare la visualizzazione delle informazioni su
  // ogni cane quando si utilizza l'istruzione print.
  @override
  String toString() {
    return 'Dog{id: $id, name: $name, age: $age}';
  }
}
