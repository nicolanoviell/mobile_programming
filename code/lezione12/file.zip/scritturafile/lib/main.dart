import 'package:flutter/material.dart';
import 'counter_storage.dart';
import 'flutter_demo.dart';

void main() {
  runApp(
    MaterialApp(
      title: 'Reading and Writing Files',
      home: FlutterDemo(storage: CounterStorage()),
    ),
  );
}
