package com.example.keyvalue

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
