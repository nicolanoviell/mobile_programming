package com.example.geminidemo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
