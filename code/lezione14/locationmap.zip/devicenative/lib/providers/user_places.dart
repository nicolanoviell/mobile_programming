import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:io';

import 'package:devicenative/models/place.dart';

class UserPlacesNotifier extends StateNotifier<List<Place>> {
  UserPlacesNotifier() : super(const []);

  void addPlace(String title, File image, PlaceLocation location) {
    // questo potete scriverlo come volete, è a vostra discrezione
    // potete passare anche un oggetto Place direttamente
    final newPlace = Place(title: title, image: image, location: location);
    // aggiorna lo stato con il nuovo luogo e il resto della lista "spalmata"
    state = [newPlace, ...state];
  }
}

final userPlacesProvider =
    StateNotifierProvider<UserPlacesNotifier, List<Place>>(
  (ref) => UserPlacesNotifier(),
);
