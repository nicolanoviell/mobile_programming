import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:devicenative/models/place.dart';

class UserPlacesNotifier extends StateNotifier<List<Place>> {
  UserPlacesNotifier() : super(const []);

  void addPlace(String title) {
    // questo potete scriverlo come volete, è a vostra discrezione
    // potete passare anche un oggetto Place direttamente
    final newPlace = Place(title: title);
    // aggiorna lo stato con il nuovo luogo e il resto della lista "spalmata"
    state = [newPlace, ...state];
  }
}

final userPlacesProvider =
    StateNotifierProvider<UserPlacesNotifier, List<Place>>(
  (ref) => UserPlacesNotifier(),
);
