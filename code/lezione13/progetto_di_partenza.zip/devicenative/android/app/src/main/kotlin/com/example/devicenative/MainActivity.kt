package com.example.devicenative

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
