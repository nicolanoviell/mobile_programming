import 'package:flutter/material.dart';
import 'package:lezione5/my_text.dart';

const startAlign = Alignment.topLeft;
const endAlign = Alignment.bottomRight;

class MyWidget extends StatelessWidget {
  const MyWidget(this.color1,
      {super.key,
      required this.color2}); // li ho definiti in maniera alternativa
  final Color color1;
  final Color color2;
  @override
  Widget build(BuildContext context) {
    return Container(
      // definiamo lo stile con Container
      decoration: BoxDecoration(
        // definiamo il gradiente
        gradient: LinearGradient(
          // specifica il gradiente
          begin: startAlign,
          end: endAlign,
          colors: [color1, color2],
        ),
      ),
      child: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image(
              image: NetworkImage(
                  'https://fastly.picsum.photos/id/870/600/400.jpg?blur=2&grayscale&hmac=vY7nsPS8gMc4HW58qg10m8534b8VtUVjYfB0ZnNYLbQ'),
            ),
            MyText('Finalmente!!!'),
          ],
        ),
      ),
    );
  }
}
