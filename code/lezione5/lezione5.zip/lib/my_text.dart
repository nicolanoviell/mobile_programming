import 'package:flutter/material.dart';

class MyText extends StatelessWidget {
  const MyText(this.text, {super.key});

  // Aggiungiamo una variabile di classe per il testo
  final String text;
  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style:
          const TextStyle(fontSize: 30, color: Colors.white), // stile del testo
    );
  }
}
