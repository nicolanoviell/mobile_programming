import 'package:flutter/material.dart';
import 'package:lezione11/widget/expenses_list/expenses_item.dart';
import 'package:lezione11/models/expense.dart';

class ExpensesList extends StatelessWidget {
  const ExpensesList({
    super.key,
    required this.listaspese,
  });

  final List<Expense> listaspese;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: listaspese.length,
      itemBuilder: (ctx, index) => ExpenseItem(listaspese[index]),
    );
  }
}
