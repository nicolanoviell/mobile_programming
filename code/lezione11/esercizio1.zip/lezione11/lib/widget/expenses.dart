import 'package:flutter/material.dart';
import 'package:lezione11/models/expense.dart';
import 'package:lezione11/widget/expenses_list/expenses_list.dart';
import 'package:lezione11/widget/new_expense.dart';

class Expenses extends StatefulWidget {
  const Expenses({super.key});

  @override
  State<Expenses> createState() => _ExpensesState();
}

class _ExpensesState extends State<Expenses> {
  final List<Expense> registeredExpenses = [
    Expense(
      title: 'Talk di Carlo Lucera',
      amount: 0.0, // è gratis, dovete esserci!!!!
      date: DateTime.now(),
      category: Category.lavoro,
    ),
    Expense(
      title: 'Tour Guidato di Capracotta',
      amount: 29.99,
      date: DateTime.now(),
      category: Category.viaggi,
    ),
    Expense(
      title: 'Espresso al bar Unimol',
      amount: 1.00,
      date: DateTime.now(),
      category: Category.cibo,
    ),
  ];

  void _openAddExpenseOverlay() {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => const NewExpense(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter ExpenseTracker'),
        actions: [
          IconButton(
            onPressed: _openAddExpenseOverlay,
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: Column(
        children: [
          const Text('The chart'),
          Expanded(child: ExpensesList(listaspese: registeredExpenses)),
        ],
      ),
    );
  }
}
