import 'package:flutter/material.dart';
import 'package:lezione11/models/expense.dart';

class ExpenseItem extends StatelessWidget {
  const ExpenseItem(this.spesa, {super.key});

  final Expense spesa;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 16,
        ),
        child: Column(
          children: [
            Text(spesa.title),
            const SizedBox(height: 4),
            Row(
              children: [
                Text(
                    '\€${spesa.amount.toStringAsFixed(2)}'), // fisso la dimensione a 2 decimali
                const Spacer(),
                Row(
                  children: [
                    Icon(categoryIcons[spesa.category]),
                    const SizedBox(width: 8),
                    Text(spesa.formattedDate),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
