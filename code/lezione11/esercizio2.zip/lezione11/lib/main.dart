import 'package:flutter/material.dart';
import 'package:lezione11/widget/expenses.dart';

void main() {
  runApp(
    const MaterialApp(
      home: Expenses(),
    ),
  );
}
