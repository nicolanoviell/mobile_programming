package com.example.lezione11

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
