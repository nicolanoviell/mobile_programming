import 'package:flutter/material.dart';
import 'package:lezione11/widget/expenses_list/expenses_item.dart';
import 'package:lezione11/models/expense.dart';

class ExpensesList extends StatelessWidget {
  const ExpensesList({
    super.key,
    required this.listaspese,
    required this.onRemoveExpense,
  });

  final List<Expense> listaspese;
  final void Function(Expense spesa) onRemoveExpense;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: listaspese.length,
      itemBuilder: (ctx, index) => Dismissible(
        key: ValueKey(listaspese[index]),
        onDismissed: (direction) {
          onRemoveExpense(listaspese[index]);
        },
        child: ExpenseItem(
          listaspese[index],
        ),
      ),
    );
  }
}
