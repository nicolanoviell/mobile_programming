import 'package:flutter/material.dart';
import 'package:lezione11/models/expense.dart';
import 'package:lezione11/widget/expenses_list/expenses_list.dart';
import 'package:lezione11/widget/new_expense.dart';

class Expenses extends StatefulWidget {
  const Expenses({super.key});

  @override
  State<Expenses> createState() => _ExpensesState();
}

class _ExpensesState extends State<Expenses> {
  final List<Expense> registeredExpenses = [
    Expense(
      title: 'Talk di Carlo Lucera',
      amount: 0.0, // è gratis, dovete esserci!!!!
      date: DateTime.now(),
      category: Category.lavoro,
    ),
    Expense(
      title: 'Tour Guidato di Capracotta',
      amount: 29.99,
      date: DateTime.now(),
      category: Category.viaggi,
    ),
    Expense(
      title: 'Espresso al bar Unimol',
      amount: 1.00,
      date: DateTime.now(),
      category: Category.cibo,
    ),
  ];
  void _addExpense(Expense expense) {
    setState(() {
      registeredExpenses.add(expense);
    });
  }

  void _removeExpense(Expense expense) {
    final expenseIndex = registeredExpenses.indexOf(expense);

    setState(() {
      registeredExpenses.remove(expense);
    });
    ScaffoldMessenger.of(context)
        .clearSnackBars(); // rimuove snackbars precedenti
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        duration: const Duration(seconds: 3),
        content: const Text('Spesa Cancellata!'),
        action: SnackBarAction(
          label: 'Annulla ',
          onPressed: () {
            setState(() {
              registeredExpenses.insert(expenseIndex, expense);
            });
          },
        ),
      ),
    );
  }

  void _openAddExpenseOverlay() {
    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      builder: (ctx) => NewExpense(onAddExpense: _addExpense),
    );
  }

  @override
  Widget build(BuildContext context) {
    Widget mainContent = const Center(
      child: Text('Non ci sono elementi nella tua lista della spesa!'),
    );
    if (registeredExpenses.isNotEmpty) {
      mainContent = ExpensesList(
        listaspese: registeredExpenses,
        onRemoveExpense: _removeExpense,
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter ExpenseTracker'),
        actions: [
          IconButton(
            onPressed: _openAddExpenseOverlay,
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: mainContent,
          ),
        ],
      ),
    );
  }
}
