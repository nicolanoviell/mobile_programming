import 'package:flutter/material.dart';
import 'package:lezione11/widget/expenses.dart';

var kColorScheme = ColorScheme.fromSeed(
  seedColor: Color.fromARGB(255, 4, 68, 70),
);

var kDarkColorScheme = ColorScheme.fromSeed(
  brightness: Brightness.dark,
  seedColor: Color.fromARGB(255, 81, 84, 84),
);

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData().copyWith(
        colorScheme: kColorScheme,
      ),
      darkTheme: ThemeData.dark().copyWith(colorScheme: kDarkColorScheme),
      themeMode:
          ThemeMode.system, // ThemeMode.system, ThemeMode.light, ThemeMode.dark
      home: const Expenses(),
    ),
  );
}
