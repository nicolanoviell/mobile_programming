import 'package:flutter/material.dart';
import 'package:lezione7/first_screen.dart';

void main() {
  runApp(
    const FirstScreen(),
  );
}
