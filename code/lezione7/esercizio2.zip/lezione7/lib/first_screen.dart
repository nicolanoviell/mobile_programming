import 'package:flutter/material.dart';
import 'package:lezione7/questions_screen.dart';
import 'package:lezione7/start_screen.dart';

class FirstScreen extends StatefulWidget {
  const FirstScreen({super.key});

  @override
  State<FirstScreen> createState() => _FirstScreenState();
}

class _FirstScreenState extends State<FirstScreen> {
  // da usare in caso di initState
  // Widget? activeScreen;

  // @override
  // void initState() {
  //   activeScreen = StartScreen(switchNewScreen);
  //   super.initState();
  // }
  var activeScreen = 'start-screen';
  void switchNewScreen() {
    setState(() {
      activeScreen = 'questions-screen';
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SafeArea(
        child: Scaffold(
          body: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.bottomRight,
                end: Alignment.topLeft,
                colors: [Colors.white, Color.fromARGB(255, 22, 60, 118)],
              ),
            ),
            // da usare in caso di initState
            // child: activeScreen,
            child: activeScreen == "start-screen"
                ? StartScreen(switchNewScreen)
                : const QuestionsWidget(),
          ),
        ),
      ),
    );
  }
}
